<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head profile="http://gmpg.org/xfn/11">
		<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
		<title><?php bloginfo('name'); ?><?php if(is_home()) { ?><? } if(is_single()) { wp_title(); } if(is_page()) { wp_title(); } ?></title>
		<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
		<link rel="shortcut icon" type="image/ico" href="/favicon.ico" />
		<!--- RSS Feeds --->
		<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> Posts" href="<?php bloginfo('rss2_url'); ?>" />
		<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> Comments" href="<?php bloginfo('comments_rss2_url'); ?>" />
		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

		<!--- Wordpress Shtuff --->
		<?php wp_get_archives('type=monthly&format=link'); ?>
		<?php wp_head(); ?>
        
        <style type="text/css" media="screen">
			@import url('<?php bloginfo('stylesheet_url'); ?>');
		</style>
        
	</head>

	<body>

	    <div id="jump">
			<?php if(is_home()) {  } else { ?><a href="<?php bloginfo('url'); ?>">Return Home</a> | <? } ?>
			<a href="#content">Skip to Content</a>
		</div>
		
	    <?php if(function_exists('wp_admin_bar')) wp_admin_bar(); ?>

	    <div id="page">
			<div id="main_graphic">
				<div id="search">
					<?php include (TEMPLATEPATH . '/searchform.php'); ?>
				</div>

				<h1><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
			</div>
	
			<div id="heading">
				<ul id="nav">
					<li class="page_item<?php if(is_home()) { ?> current_page_item<? } ?><?php if(is_single()) { ?> current_page_item<? } ?>"><a href="<?php bloginfo('url'); ?>" title="Home">Home</a></li>
					<?php wp_list_pages('title_li=&depth=1'); ?>
				</ul>
			</div>