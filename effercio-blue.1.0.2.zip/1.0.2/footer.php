			<div class="clearfix"></div>
		</div>

		<!--- start footer --->
		<div id="footer">
				<ul id="credits">
					<li class="wp">Powered by <a href="http://wordpress.org" title="WordPress">WordPress</a>.</li>
					<li class="author">
						<strong>Effercio Blue</strong> theme by <a href="http://cdharrison.com" title="Chris Harrison">Chris Harrison</a>
						and <a href="http://powerserve.net">PowerServe</a>.</li>
				</ul>
			</div>
			
			<div style="clear:both;"></div>
		</div>
		<!--- /end footer --->
        
	</body>
</html>
<!--- <?php echo get_num_queries(); ?> --->