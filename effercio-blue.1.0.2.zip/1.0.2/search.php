<?php get_header(); ?>

   <div id="content" class="search-results">

	<?php if (have_posts()) : ?>
    
    	<div class="post">

			<h2 class="title">Search Results</h2>
			<p>Below are the posts that match your search criteria. If it's not quite what you were looking for,
			you could always searching for something else:</p>

			<?php include (TEMPLATEPATH . '/searchform.php'); ?>
		
			<div style="clear:both;"></div>
            
            <ol class="searchresults">
            <?php while (have_posts()) : the_post(); ?>
            <li>
                <strong>
                    <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a>
                </strong> &#0151;
                <span class="metadata">
                    <span class="date">Posted on <?php the_time('m.d.Y') ?> at <?php the_time() ?></span> &middot;
                    <span class="respond"><?php comments_popup_link(__('Respond'), __('Comments (1)'), __('Comments (%)'), 'commentslink', __('Comments off')); ?></span>
                    <?php edit_post_link(__('Edit'), ' &middot; <span class="edit"> ', '</span>'); ?>
                </span>
            </li>
            <?php endwhile; ?>
            </ol>
            
            <div class="browse-entries">
                <div class="prev"><?php next_posts_link('&laquo; Previous Entries') ?></div>
                <div class="next"><?php previous_posts_link('Next Entries &raquo;') ?></div>
                <div style="clear:both;"></div>
            </div>

        </div>

	<?php else : ?>
    
    	<div class="post">

			<h2 class="title">No posts found.</h2>
            <p>How about searching for something else?</p>
            
			<?php include (TEMPLATEPATH . '/searchform.php'); ?>

		</div>

	<?php endif; ?>

	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>