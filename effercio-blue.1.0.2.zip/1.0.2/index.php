<?php get_header();

function stupid_hack($str) {
	return preg_replace('|</ul>\s*<ul class="asides">|', '', $str);
	}
ob_start('stupid_hack');

?>

   <div id="content" class="home">
   	<h3>Latest<em>Stuff</em></h3>
   
	<?php if (have_posts()) : ?>

	<?php while (have_posts()) : the_post(); ?>
	
		<?php if (in_category(38) && !$single) { ?>
			<ul class="asides">
				<li id="p<?php the_ID(); ?>"><?php echo wptexturize($post->post_content); echo ' ';?>
                	<div class="tools-inline">
	                	<span class="comments"><?php comments_popup_link(__('(0)'), __('(1)'), __('(%)'), 'commentslink', __('')); ?></span>
						<span class="permalink"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to '<?php the_title(); ?>'">#</a></span>
    	                <?php edit_post_link(__('E'), '<span class="edit_post_link"> ', '</span>'); ?>
                    </div>
                </li>
			</ul>
		<?php } else { ?>
			
			<div class="post" id="post-<?php the_ID(); ?>">
				<h2 class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to '<?php the_title(); ?>'"><?php the_title(); ?></a></h2>
				<script src="http://feeds.feedburner.com/~s/cdharrison?i=<?php the_permalink() ?>" type="text/javascript" charset="utf-8"></script>
				<p class="metadata">
					<span class="date"><?php the_time('m.d.Y') ?></span> at
					<span class="time"><?php the_time() ?></span> by
					<span class="user"><?php the_author() ?></span>
				</p>
			
				<div class="entry">
					<?php the_content("<p class=\"continue\">" . __('Read the Rest of','') . " '" . the_title('', '', false) . "'</p>"); ?>
				</div>
				
				<div class="tools">
					<span class="comments"><?php comments_popup_link(__('Respond'), __('Comments (1)'), __('Comments (%)'), 'commentslink', __('Comments off')); ?></span>
					<span class="permalink"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to '<?php the_title(); ?>'">Permalink</a></span>
					<?php edit_post_link(__('Edit'), '<span class="edit_post_link"> ', '</span>'); ?>
				</div>
			</div>
			
		<?php } ?>
				
	<? endwhile; ?>
				
		<div class="browse clearfix">
			<?php posts_nav_link(' &#151; ','Previous Entries','Next Entries'); ?> 
		</div>
		
	<?php else : ?>
	
			<h2>Not Found</h2>
			<p>Sorry, but you are looking for something that isn't here.</p>
			<?php include (TEMPLATEPATH . "/searchform.php"); ?>
			
	<?php endif; ?>


	
	
	</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>